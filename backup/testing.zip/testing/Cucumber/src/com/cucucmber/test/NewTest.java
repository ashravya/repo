package com.cucucmber.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest {
	WebDriver driver;
  @Test
  public void reg() throws InterruptedException {
	  Thread.sleep(1000);
	driver.findElement(By.xpath(".//*[@id='account']/a")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath(".//*[@id='meta']/ul/li[1]/a")).click();
	driver.findElement(By.cssSelector("#user_login ")).sendKeys("user");
	driver.findElement(By.cssSelector("#user_email")).sendKeys("usermail@gmail.com");
	//driver.findElement(By.cssSelector("#aiowps-captcha-answer")).sendKeys("");
	//driver.findElement(By.cssSelector("#wp-submit")).click();
  }
  @BeforeTest
  public void beforeTest()
  {
	  System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		  	  driver.get("http://store.demoqa.com/"); 

  }
}
