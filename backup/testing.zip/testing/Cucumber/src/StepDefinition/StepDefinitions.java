package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {

	WebDriver driver;
	
	/*@Given("^Launch Browser and Navigate to Application$")
	public void Launch_Browser_and_Navigate_to_Application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://store.demoqa.com/");
		driver.manage().window().maximize();
	}*/
	
	@Given("^Launch Browser and Navigate to Application \"([^\"]*)\"$")
	public void Launch_Browser_and_Navigate_to_Application(String url) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
	}

	@When("^Navigate to Login Page$")
	public void Navigate_to_Login_Page() throws Throwable {

		driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='meta']/ul/li[2]/a")).click();
	}

	/*@Then("^Enter valid username and valid Password$")
	public void Enter_valid_username_and_valid_Password() throws Throwable {

		driver.findElement(By.cssSelector("#user_login ")).sendKeys("user");
		driver.findElement(By.xpath(".//*[@id='user_pass']")).sendKeys("usermail@gmail.com");
		//driver.findElement(By.xpath(".//*[@id='wp-submit']")).click();
	}*/
	
	@Then("^Enter valid \"([^\"]*)\" and valid \"([^\"]*)\"$")
	public void Enter_valid_and_valid(String userName, String password) throws Throwable {
		driver.findElement(By.cssSelector("#user_login ")).sendKeys(userName);
		driver.findElement(By.xpath(".//*[@id='user_pass']")).sendKeys(password);
	}

}
