import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenApp {
	WebDriver driver;
	public void createDriver() {
		this.driver = new FirefoxDriver();
	}
	
	public void closeDriver() {
		if(this.driver!=null){
			driver.close();
		}
	}
	
	
	private void HomeNav(){
		this.driver.get("http://store.demoqa.com/");
	}
	
	private boolean reg(){
		this.driver.findElement(By.cssSelector("a[title='My Account']")).click();
		this.driver.findElement(By.linkText("Register")).click();
		this.driver.findElement(By.cssSelector("#user_login ")).sendKeys("user");
		this.driver.findElement(By.cssSelector("#user_email")).sendKeys("usermail");
		this.driver.findElement(By.cssSelector("#aiowps-captcha-answer")).sendKeys("");
		this.driver.findElement(By.cssSelector("#wp-submit")).click();
		return true;
	}
	
	private void login(){
		this.driver.findElement(By.cssSelector("a[title='My Account']")).click();
		this.driver.findElement(By.linkText("Log in")).click();
		this.driver.findElement(By.cssSelector("#user_login")).sendKeys("krishnatejaperannagari");
		this.driver.findElement(By.cssSelector("#user_pass")).sendKeys("krishnatejaperannagari");
		//this.driver.findElement(By.cssSelector("#wp-submit")).click();
	}
	
	public static void main(String[] args) {
		OpenApp test = new OpenApp();
		test.createDriver();
		test.HomeNav();
		//test.register();
		test.login();
		test.closeDriver();
	}

}
