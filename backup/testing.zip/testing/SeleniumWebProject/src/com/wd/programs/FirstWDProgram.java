package com.wd.programs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirstWDProgram {

	public static void main(String[] args) {

		//System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		//WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.edge.driver", "D:\\Selenium software\\MicrosoftWebDriver.exe");
		WebDriver driver=new EdgeDriver();
		//WebDriver driver = new FirefoxDriver();//open the browser
		driver.get("http://www.google.co.in");//http is mandatory
		driver.manage().window().maximize();
		driver.findElement(arg0)

	}

}
