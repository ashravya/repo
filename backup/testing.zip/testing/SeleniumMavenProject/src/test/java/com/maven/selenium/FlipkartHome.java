package com.maven.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FlipkartHome {
	WebDriver driver = new FirefoxDriver();

	@BeforeTest
	public void beforeTest() {

		driver.manage().window().maximize();
		// driver.get("https://www.flipkart.com/");
	}

	@Test
	public void login() throws InterruptedException {
		driver.get("https://www.flipkart.com/");
		driver.findElement(By.linkText("Log In")).click();
		driver.findElement(By.cssSelector("input[class='_2zrpKA'][type='text']")).sendKeys("shravya.anchuru@gmail.com");
		driver.findElement(By.cssSelector("._2zrpKA._3v41xv")).sendKeys("shravya1995");
		driver.findElement(By.cssSelector("._3zLR9i._1LctnI._36SmAs")).click();
		driver.findElement(By.cssSelector("._1AHrFc")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("a[href*='logout']")).click();
	}

	@Test(dependsOnMethods = "login")
	public void search() {
		driver.findElement(
				By.xpath(".//*[@id='container']/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[1]/div/input"))
				.sendKeys("Selenium WebDriver");
		driver.findElement(By.className("vh79eN")).click();
	}

	@Test(dependsOnMethods = "search")
	public void bookDetails() throws IOException {
		/*List<WebElement> bname =driver.findElements(By.cssSelector("a[class='_2cLu-1']"));
		List<WebElement> bprice=driver.findElements(By.cssSelector("div[class='_1vC4OE']"));
		File file = new File("C:\\Users\\Shravya_Anchuru\\Desktop\\testing\\Book1.xlsx");
		FileInputStream ifile = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(ifile);
		XSSFSheet sheet = wb.getSheet("Info");
		
		for (int i = 1; i <= bname.size(); i = i + 1)
		{
			sheet.getRow(i).getCell(1).setCellValue("bname[i]");
		}
		for (int i = 1; i <= bprice.size(); i = i + 1)
		{
			sheet.getRow(i).getCell(2).setCellValue("bprice[i]");
		}
		
		FileOutputStream ofile = new FileOutputStream(file);
		wb.write(ofile);
		ofile.close();*/
		List<WebElement> list = driver.findElements(By.xpath("//a[@class='_2cLu-l']"));
		  
		   String[] names=new String[6];  
		   for(int i=0;i<list.size();i++)
		   { names[i]=list.get(i).getText();
		   System.out.println(list.get(i).getText()); }
		     
		  List<WebElement> list1 = driver.findElements(By.className("_1vC4OE"));
		  String[] price = new String[6];
		  for (int i = 0; i < list1.size(); i++) {
		   price[i] = list1.get(i).getText();
		  }
		   for(int i=0;i<names.length;i++){ System.out.print(names[i]);
		   System.out.println(price[i]); }
		   
		  
		 
		   FileInputStream fis=new FileInputStream("C:\\Users\\Shravya_Anchuru\\Desktop\\testing\\Book1.xlsx");
		   XSSFWorkbook wb=new XSSFWorkbook(fis);
		   XSSFSheet sheet=wb.getSheet("Info");
		   for(int i=1;i<list.size();i++){ 
		    XSSFRow row=sheet.createRow(i); row.createCell(0); row.createCell(1);
		  sheet.getRow(i).getCell(0).setCellValue(names[i-1]);
		  sheet.getRow(i).getCell(1).setCellValue(price[i-1]);
		  }
		  FileOutputStream fos=new FileOutputStream("C:\\Users\\Shravya_Anchuru\\Desktop\\testing\\Book1.xlsx"); 
		  wb.write(fos);
		  wb.close();
	}
	
	@Test(dependsOnMethods = "bookDetails")
	public void addCart()
	{
		driver.findElement(By.xpath(".//*[@id='container']/div/div[2]/div[2]/div/div[2]/div[3]/div[1]/div[1]/div/a[2]")).click();
		driver.findElement(By.cssSelector("button[class='_3zLR9i _3Plo8Q _19RW-r']")).click();
		
	}
}