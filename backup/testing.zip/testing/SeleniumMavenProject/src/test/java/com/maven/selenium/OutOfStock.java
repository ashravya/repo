package com.maven.selenium;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class OutOfStock {
	WebDriver driver;
		
	
//TESTCASE 3
	
	
	
	@Test
	public void customerLogin() {
		// Switching between tabs using CTRL + tab keys.
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "\t");
		// Switch to current selected tab's content.
		driver.switchTo().defaultContent();

		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
		driver.findElement(By.xpath(".//*[@id='input-email']")).sendKeys("shravya@gmail.com");
		driver.findElement(By.xpath(".//*[@id='input-password']")).sendKeys("shravya");
		driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div/form/input")).click();

	}

	@Test(dependsOnMethods = "customerLogin")
	public void addToCart() throws InterruptedException, AWTException, IOException {
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[4]/a")).click();
		driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();

		if (driver.findElement(By.xpath("html/body/div[2]/div[1][@class='alert alert-danger']")) != null) {
			driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/span/button[2]"))
					.click();
		}

		driver.findElement(By.xpath(".//*[@id='content']/div/div/a")).click();

		driver.switchTo().alert().accept();
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[3]/a")).click();
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[3]/div/div/ul/li[2]/a")).click();

		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='input-option218']/div[2]/label/input")).click();
		driver.findElement(By.xpath(".//*[@id='input-option223']/div[1]/label/input")).click();
		driver.findElement(By.xpath(".//*[@id='input-option223']/div[2]/label/input")).click();
		driver.findElement(By.xpath(".//*[@id='input-option208']")).sendKeys("TEST123");

		WebElement mySelectEle = driver.findElement(By.id("input-option217"));
		Select mySelect = new Select(mySelectEle);
		mySelect.selectByValue("4");
		driver.findElement(By.xpath(".//*[@id='input-option209']")).sendKeys("Text Area");
		// driver.findElement(By.xpath(".//*[@id='button-upload222']")).click();
		WebElement fileUpload = driver.findElement(By.id("button-upload222"));
		fileUpload.click();
		Runtime.getRuntime().exec("C:\\Users\\Shravya_Anchuru\\Desktop\\upload.exe");
		driver.switchTo().alert().accept();
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
		driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
		// driver.switchTo().alert().accept();
	}

	@Test(dependsOnMethods = "addToCart")
	public void checkOut() throws InterruptedException {
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/input")).click();
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/input")).clear();
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/input")).sendKeys("3");
		driver.findElement(By.xpath(".//*[@id='content']/form/div/table/tbody/tr/td[4]/div/span/button[1]")).click();

		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[2]/a")).click();
		Thread.sleep(1000);
	
		//continue buttons
		driver.findElement(By.xpath(".//*[@id='button-payment-address']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-shipping-address']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-shipping-method']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='collapse-payment-method']/div/div[2]/div/input[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-payment-method']")).click();

		driver.findElement(By.xpath(".//*[@id='button-confirm']")).click();

	}

	@Test(dependsOnMethods = "checkOut")
	public void adminProduct() throws InterruptedException {

		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "\t");
		driver.switchTo().defaultContent();
		
		driver.findElement(By.xpath(".//*[@id='input-username']")).sendKeys("admin");
		driver.findElement(By.xpath(".//*[@id='input-password']")).sendKeys("admin");
		driver.findElement(By.xpath(".//*[@id='content']/div/div/div/div/div[2]/form/div[3]/button")).click();
		
		driver.findElement(By.xpath(".//*[@id='header']/ul/li[1]/a")).click();
		driver.findElement(By.xpath(".//*[@id='header']/ul/li[1]/ul/li[2]/a")).click();
		
		//driver.findElement(By.xpath(".//*[@id='input-order-status']")).click();
		WebElement mySelectEle = driver.findElement(By.id("input-order-status"));
		Select mySelect = new Select(mySelectEle);
		mySelect.selectByValue("1");
		driver.findElement(By.xpath(".//*[@id='button-filter']")).click();
		
		
		driver.findElement(By.xpath(".//*[@id='form-order']/div/table/tbody/tr[1]/td[8]/a[2]")).click();
		driver.findElement(By.xpath(".//*[@id='button-customer']")).click();
		//driver.findElement(By.xpath(".//*[@id='cart']/tr/td[3]/div/input")).sendKeys(arg0);
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-payment-address']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='button-shipping-address']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='button-payment-method']")).click();
		//driver.findElement(By.xpath(".//*[@id='input-order-status']"));
		Thread.sleep(1000);
		WebElement mySelectEle1 = driver.findElement(By.id("input-order-status"));
		Select mySelect1 = new Select(mySelectEle1);
		mySelect1.selectByValue("3");
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-save']")).click();
				
	}

	
	
	/*
	//TESTCASE11
	
	
	
	@Test
	public void adminLogin() {
		driver.findElement(By.xpath(".//*[@id='input-username']")).sendKeys("admin");
		driver.findElement(By.xpath(".//*[@id='input-password']")).sendKeys("admin");
		driver.findElement(By.xpath(".//*[@id='content']/div/div/div/div/div[2]/form/div[3]/button")).click();
	}

	@Test
	public int Menu() throws InterruptedException 
	{
		driver.findElement(By.xpath(".//*[@id='button-menu']")).click();//ButtonMenu
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='menu-sale']/a")).click();//SalesinButtonMenu
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='menu-sale']/ul/li[1]/a")).click();//OrdersinSales
		
		WebElement mySelectEle = driver.findElement(By.id("input-order-status"));//orderStatus
		Select mySelect = new Select(mySelectEle);
		mySelect.selectByValue("1");
		driver.findElement(By.xpath(".//*[@id='button-filter']")).click();//filter
		int Row_count = driver.findElements(By.xpath(".//*[@id='form-order']/div/table/tbody/tr")).size();//filteredTable
		return (Row_count);
	}
	@Test
	public void reductionCountlist() throws InterruptedException
	{
		int firstCount=Menu();
		driver.findElement(By.xpath(".//*[@id='form-order']/div/table/tbody/tr[1]/td[8]/a[2]")).click();//Action
		driver.findElement(By.xpath(".//*[@id='button-customer']")).click();//continue in customer details
		//driver.findElement(By.xpath(".//*[@id='cart']/tr/td[3]/div/input")).sendKeys(arg0);
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();//continue in products
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-payment-address']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='button-shipping-address']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='button-payment-method']")).click();
		//driver.findElement(By.xpath(".//*[@id='input-order-status']"));
		Thread.sleep(1000);
		WebElement mySelectEle1 = driver.findElement(By.id("input-order-status"));
		Select mySelect1 = new Select(mySelectEle1);
		mySelect1.selectByValue("3");
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='button-save']")).click();
		driver.switchTo().alert().dismiss();
		int secondCount=Menu();
		if(firstCount>secondCount)
		{
			System.out.println("Reduced because the item is shipped");
		}
		else
		{
			System.out.println("NOT REDUCED");
		}
	}*/
	
	
	//TESTCASE 12
	
	/*@Test
	public void customerLogin()
	{
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "\t");
		driver.switchTo().defaultContent();

		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")).click();
		driver.findElement(By.xpath(".//*[@id='input-email']")).sendKeys("shravya@gmail.com");
		driver.findElement(By.xpath(".//*[@id='input-password']")).sendKeys("shravya");
		driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div/form/input")).click();
	}
	
	@Test(dependsOnMethods="customerLogin")
	public void dadd3() throws InterruptedException
	{
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[2]/a")).click();//Laptops & Notebooks
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[2]/div/a")).click();//Show All Laptops & Notebooks
		driver.findElement(By.xpath(".//*[@id='content']/div[4]/div[2]/div/div[2]/div[2]/button[1]")).click();//MacBook
		driver.findElement(By.xpath(".//*[@id='content']/div[4]/div[3]/div/div[2]/div[2]/button[1]")).click();//MacBook Air
		driver.findElement(By.xpath(".//*[@id='content']/div[4]/div[5]/div/div[2]/div[2]/button[1]")).click();//Sony VAIO
	}
	@Test(dependsOnMethods="dadd3")
	public void checkOut() throws InterruptedException
	{
		driver.findElement(By.xpath(".//*[@id='cart']/button")).click();//cartButton
		driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[2]/strong")).click();//checkout
		driver.findElement(By.xpath(".//*[@id='button-payment-address']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='button-shipping-address']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='button-shipping-method']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='collapse-payment-method']/div/div[2]/div/input[1]")).click();
		driver.findElement(By.xpath(".//*[@id='button-payment-method']")).click();
		driver.findElement(By.xpath(".//*[@id='button-confirm']")).click();//confirmOrder
	}*/
	
	
	@Parameters("browserType")
	@BeforeTest
	public void beforeTest(String browser) {

		driver = Drivers.getDriver(browser);
		driver.get("http://localhost/opencart/upload");
		Actions act = new Actions(driver);
		act.keyDown(Keys.CONTROL).sendKeys("t").keyUp(Keys.CONTROL).perform();
		driver.get("http://localhost/opencart/upload/admin");

	}

	@AfterTest
	public void afterTest() {
		// driver.close();
	}

}
