package com.mercurytours.pages;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmazonHome {
	WebDriver driver;
	
	//@FindBy(name="field-keywords") WebElement keyword;
	public AmazonHome(WebDriver driver) {
		this.driver = driver;
	}
	
	public void openApp(String url){
		driver.get(url);
	}
	
	/*public void search()
	{
		keyword.sendKeys(driver.findElement(By.xpath(".//*[@id='twotabsearchtextbox']")).getText());
	}*/
}
