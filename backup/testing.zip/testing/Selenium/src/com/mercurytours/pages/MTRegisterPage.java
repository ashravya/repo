package com.mercurytours.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MTRegisterPage {

	WebDriver driver;
	
	
	public MTRegisterPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(linkText="REGISTER") WebElement RegisterButton;
	@FindBy(name="email") WebElement UserName;
	@FindBy(name="password") WebElement Password;
	@FindBy(name="confirmPassword") WebElement Confirm;
	@FindBy(name="register") WebElement Submit;
	@FindBy(linkText="SIGN-OFF") WebElement SignOff;
	
	public void openApp(String url){
		driver.get(url);
	}
	
	public void registerButton(){
		RegisterButton.click();
	}
	
	public void register(String user,String pass){
		UserName.sendKeys(user);
		Password.sendKeys(pass);
		Confirm.sendKeys(pass);
		Submit.click();		
	}
	
	public void signOff(){
		SignOff.click();
	}
}

