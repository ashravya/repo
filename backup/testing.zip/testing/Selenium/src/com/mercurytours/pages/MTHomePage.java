package com.mercurytours.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MTHomePage {
	
	
	WebDriver driver;
	@FindBy(name="userName") WebElement UserName;
	@FindBy(name="password") WebElement Password;
	@FindBy(xpath="//*[@value='Login']") WebElement LoginButton;
	
	
	public MTHomePage(WebDriver driver) {
		this.driver = driver;
	}

	public void openApp(String url){
		driver.get(url);
	}
	public void login(String un,String pwd){
		UserName.sendKeys(un);
		Password.sendKeys(pwd);
		LoginButton.click();
	}
}
