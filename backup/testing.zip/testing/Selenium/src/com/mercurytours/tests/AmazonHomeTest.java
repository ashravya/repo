package com.mercurytours.tests;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.mercurytours.pages.AmazonHome;
import com.wd.testng.Drivers;

public class AmazonHomeTest {
	WebDriver driver;

	@Test
	public void homeTest() {

		AmazonHome ahome = PageFactory.initElements(driver, AmazonHome.class);
		ahome.openApp("http://www.amazon.in//");
	}

	@Test(dependsOnMethods = "homeTest")
	public void category() {
		driver.findElement(By.xpath(".//*[@id='nav-link-shopall']/span[2]")).click();
		driver.findElement(By.xpath(".//*[@id='nav-flyout-shopAll']/div[2]/span[3]/span")).click();
		driver.findElement(By.xpath(".//*[@id='nav-flyout-shopAll']/div[3]/div[3]/div[1]/div/a[1]/span")).click();
	}

	@Test(dependsOnMethods = "category")
	public void search() {
		driver.findElement(By.xpath(".//*[@id='twotabsearchtextbox']")).sendKeys("webdriver");
		driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input")).click();
		/*
		 * AmazonHome ahome = PageFactory.initElements(driver,
		 * AmazonHome.class); ahome.search();
		 */
	}

	@Test(dependsOnMethods ="search")
	public void bookDetails(){
		//to get the book names
		List<WebElement> list =driver.findElements(By.xpath("//h2[@class='a-size-medium a-color-null s-inline s-access-title a-text-normal']"));

		String[] names = new String[50];
		for (int i = 0; i < list.size(); i++) {
			names[i] = list.get(i).getText();
			System.out.println(list.get(i).getText());
		}

		//to get the book prices
		List<WebElement> list1 = driver.findElements(By.className("a-size-base a-color-price s-price a-text-bold"));
		String[] price = new String[50];
		for (int i = 0; i < list1.size(); i++) {
			price[i] =list1.get(i).getText();
			price[i]=price[i].substring(1,price[i].length());
		}
		/*for (int i = 0; i < names.length; i++) {
			System.out.print(names[i]);
			System.out.println(price[i]);
		}*/
		
		int highest=0,lowest=0;
		int highestIndex=0,lowestIndex=0;
		
		//highest ans lowest prices books
		for(int i=0;i<list1.size();i++)
		{
			int iprice=Integer.parseInt(price[i]);
			for(int j=1;j<list1.size();j++)
			{
				int jprice=Integer.parseInt(price[j]);
				if(iprice>jprice)
				{
					highest=iprice;
					highestIndex=i;
			
					lowest=jprice;
					lowestIndex=j;
				}
				else
				{
					highest=jprice;
					highestIndex=j;
			
					lowest=iprice;
					lowestIndex=i;
				}
			}
		}
		System.out.println("Highest " + names[highestIndex] +" "+ highest);
		System.out.println("Lowest " + names[lowestIndex]+" "+lowest);
		/*WebElement web = driver.findElement(By.xpath(
                ".//*[@class='s-result-list s-col-1 s-col-ws-1 s-result-list-hgrid s-height-equalized s-list-view s-text-condensed s-item-container-height-auto']"));
        String[] list = { web.getText() };
        for (int i = 0; i < list.length; i++) {
            System.out.println(list[i]);
            
        }*/
	}

	@BeforeTest
	public void beforeTest() {
		driver = Drivers.getDriver("firefox");
	}

}
