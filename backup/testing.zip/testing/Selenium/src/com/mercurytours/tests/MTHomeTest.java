package com.mercurytours.tests;

import org.testng.annotations.Test;

import com.mercurytours.pages.MTHomePage;
import com.mercurytours.pages.MTRegisterPage;
import com.wd.testng.Drivers;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;

public class MTHomeTest {
	WebDriver driver;

	/*
	 * @Test public void HomeTest() { MTHomePage
	 * mtHome=PageFactory.initElements(driver, MTHomePage.class);
	 * mtHome.openApp("http://newtours.demoaut.com/"); mtHome.login("mercury",
	 * "mercury"); }
	 * 
	 * @BeforeTest public void beforeTest() { driver =
	 * Drivers.getDriver("firefox"); }
	 * 
	 * @AfterTest public void afterTest() { }
	 * 
	 * }
	 */
	public String user = "mercury";
	public String pass = "mercury";

	@Test
	public void registration() {
		MTRegisterPage reg = PageFactory.initElements(driver, MTRegisterPage.class);
		reg.openApp("http://newtours.demoaut.com/");
		reg.registerButton();
		reg.register(user, pass);
		reg.signOff();
	}

	@Test(dependsOnMethods = "registration")
	public void homeTest() {
		MTHomePage mtHome = PageFactory.initElements(driver, MTHomePage.class);
		mtHome.login(user, pass);
	}

	@BeforeTest 
	public void beforeTest() {
		driver =Drivers.getDriver("firefox"); }

	@AfterTest
	public void afterClass() {
		// driver.close();
	}
}
