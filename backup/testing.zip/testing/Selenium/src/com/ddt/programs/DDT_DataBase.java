package com.ddt.programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class DDT_DataBase {
 WebDriver driver;
 public DDT_DataBase(WebDriver driver) {
  // TODO Auto-generated constructor stub
  this.driver = driver;
 }
 public void openUrl(String url) {
  driver.get(url);
 }
 public boolean login(String username, String password) {
  driver.findElement(By.name("userName")).sendKeys(username);
  driver.findElement(By.name("password")).sendKeys(password);
  driver.findElement(By.name("login")).click();
  if (driver.getTitle().contains("Find a Flight")) {
   driver.findElement(By.linkText("SIGN-OFF")).click();
   return true;
  } else
   return false;
 }
 public void connectToDb() throws SQLException, ClassNotFoundException {
  Class.forName("com.mysql.jdbc.Driver");
  Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/DDT", "root", "root");
  ResultSet rs;
  Statement stmt1 = conn.createStatement();
  Statement stmt2 = conn.createStatement();
  rs = stmt1.executeQuery("select username, password from logindb");
  while(rs.next()){
   if(login(rs.getString(1),rs.getString(2))){
    stmt2.executeUpdate("UPDATE logindb SET result='Right' where username='"+rs.getString(1)+"' and password='"+rs.getString(2)+"'");
   }else stmt2.executeUpdate("UPDATE logindb SET result='Wrong' where username='"+rs.getString(1)+"' and password='"+rs.getString(2)+"'");
  }
 }
 public static void main(String[] args) throws ClassNotFoundException, SQLException {
  // TODO Auto-generated method stub
  WebDriver driver=new FirefoxDriver();
  DDT_DataBase ddtdb=new DDT_DataBase(driver);
  ddtdb.openUrl("http://newtours.demoaut.com/");
  ddtdb.connectToDb();
 }
}
