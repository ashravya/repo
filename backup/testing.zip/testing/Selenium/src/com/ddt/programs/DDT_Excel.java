package com.ddt.programs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DDT_Excel {
	WebDriver driver;

	public DDT_Excel(WebDriver driver) {
		this.driver = driver;
	}

	public void openApplication(String appUrl) {
		driver.get(appUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	private String login(String username, String password) {
		// TODO Auto-generated method stub
		driver.findElement(By.name("userName")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		if (driver.getTitle().contains("Find a Flight")) {
			driver.findElement(By.linkText("SIGN-OFF")).click();
			// if (username == password)
			return "Success";
			// else
			// return "Failure";
		} else {
			return "Failure";
		}
	}

	public void readExcel(String excelPath, String wbName, String sheetName) throws IOException {

		File file = new File(excelPath + "\\" + wbName);
		FileInputStream ifile = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(ifile);
		XSSFSheet sheet = wb.getSheet(sheetName);
		System.out.println("total number of rows:" + sheet.getLastRowNum());
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			String un = sheet.getRow(i).getCell(0).getStringCellValue();
			String pwd = sheet.getRow(i).getCell(1).getStringCellValue();
			String output = this.login(un, pwd);
			sheet.getRow(i).getCell(2).setCellValue(output);
		}
		ifile.close();
		FileOutputStream ofile = new FileOutputStream(file);
		wb.write(ofile);
		ofile.close();
	}

	public void validate(String excelPath, String wbName, String sheetName) throws IOException {
		File file = new File(excelPath + "\\" + wbName);
		FileInputStream ifile = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(ifile);
		XSSFSheet sheet = wb.getSheet(sheetName);
		System.out.println("total number of rows:" + sheet.getLastRowNum());
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {

			for (int j = 0; j < sheet.getRow(i).getLastCellNum()-1; j++) {
				XSSFCell cell = (XSSFCell) sheet.getRow(i).getCell(j);
				if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
					System.out.println("The Cell was a String with value \" " + cell.getStringCellValue() + " \" ");
				} else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
					System.out.println("The cell was a number " + cell.getNumericCellValue());
				} else {
					System.out.println("The cell was nothing we're interested in");
				}
			}
		}
		wb.close();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		DDT_Excel ddt = new DDT_Excel(driver);
		ddt.openApplication("http://newtours.demoaut.com/");
		try {
			ddt.readExcel("C:\\Users\\Shravya_Anchuru\\Desktop\\testing", "DDTexcel.xlsx", "MTLoginData");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ddt.validate("C:\\Users\\Shravya_Anchuru\\Desktop\\testing", "DDTexcel.xlsx", "MTLoginData");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
