package com.ddt.programs;

import java.awt.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;



import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class Validation {
    static WebDriver driver;
    protected static XSSFSheet excelWSheet;
    protected static XSSFWorkbook excelWBook;
    private static XSSFCell cell;
    private static XSSFRow row;
    //
    static String web;
    static String query;

    // Setting the file to read from
    public static void setExcelFile() throws FileNotFoundException {
        FileInputStream file = null;

        try {
            file = new FileInputStream("C:\\Users\\Shravya_Anchuru\\Desktop\\testing\\SearchEngines.xlsx");
            excelWBook = new XSSFWorkbook(file);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        } finally {
            if (file != null) {
                try {
                    file.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    // Counting the used rows in every work sheet and give you the work sheets data
    public static void getSheetData() {
        int index = 0;  
        for (int i = 0; i < excelWBook.getNumberOfSheets(); i++) {
            index++;
            System.out.println("Sheet Name: " + "["
                    + excelWBook.getSheetName(i) + "] --> " + "Sheet index: "
                    + "[" + index + "]\n");

        }
        int rowIndex = 0;
        for (int i = 0; i < excelWBook.getSheetAt(0).getLastRowNum()+1; i++) {
            excelWSheet = excelWBook.getSheetAt(0);
            rowIndex++;

        }
        System.out.println("Number of rows including the header: --> " + rowIndex);
        System.out.println("Number of rows not including the header: --> " +excelWSheet.getLastRowNum());
        System.out.println();


        int rowIndex2 = 0;
        for (int i = 0; i < excelWBook.getSheetAt(1).getLastRowNum()+1; i++) {
            excelWSheet = excelWBook.getSheetAt(1);
            rowIndex2++;

        }
        System.out.println("Number of rows including the header: --> " + rowIndex2);
        System.out.println("Number of rows not including the header: --> " +excelWSheet.getLastRowNum());
        System.out.println();


    // Going through the SearchEngines work sheet to get the data from every used cell and prints it out

        Iterator<Row> rowIterator = excelWSheet.iterator();
        while(rowIterator.hasNext()) {
            Row row = rowIterator.next();

            Iterator<Cell> cellIterator = row.cellIterator();
            while(cellIterator.hasNext()) {

                Cell cell = cellIterator.next();

                switch (cell.getCellType()) {
                case Cell.CELL_TYPE_BOOLEAN:
                    System.out.println(cell.getBooleanCellValue() + "\t\t");
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    System.out.println(cell.getNumericCellValue() + "\t\t");
                case Cell.CELL_TYPE_STRING:
                    web = cell.getStringCellValue();
                    System.out.println(web + "\t\t");

                default:
                    break;
                }
            }
            System.out.println("");
        }
        // Going through the queries work sheet to get the data from every used cell and prints it out
        Iterator<Row> rowIterator2 = excelWSheet.iterator();
            while(rowIterator2.hasNext()) {
                Row row = rowIterator2.next();

                Iterator<Cell> cellIterator = row.cellIterator();
                while(cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();

                    switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_BOOLEAN:
                        System.out.println(cell.getBooleanCellValue() + "\t\t");
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                        System.out.println(cell.getNumericCellValue() + "\t\t");
                        break;
                    case Cell.CELL_TYPE_STRING:
                        System.out.println(cell.getStringCellValue() + "\t\t");
                        break;

                    default:
                        break;
                    }
                }
                System.out.println("");
            }
    }  
}