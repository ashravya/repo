package com.ddt.programs;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class DDT_Csv {
	WebDriver driver;

	public DDT_Csv(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	public void openUrl(String url) {
		driver.get(url);
	}

	public boolean login(String username, String password) {
		driver.findElement(By.name("userName")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		if (driver.getTitle().contains("Find a Flight")) {
			driver.findElement(By.linkText("SIGN-OFF")).click();
			return true;
		} else
			return false;
	}

	public void readCSV(String CSVPath, String CSVFileName) throws IOException {
		List<String[]> lsarray = new ArrayList<String[]>();
		String file = CSVPath + "\\" + CSVFileName;
		CSVReader csvreader = new CSVReader(new FileReader(file));
		String[] line;
		int i = 0;
		while ((line = csvreader.readNext()) != null) {
			if (i == 0) {
				i++;
				lsarray.add(line);
			} else {
				if (login(line[0], line[1])) {
					line[2] = "Success";
					lsarray.add(line);
				} else {
					line[2] = "Failure";
					lsarray.add(line);
				}
			}
		}
		csvreader.close();
		CSVWriter csvwriter = new CSVWriter(new FileWriter(file));
		csvwriter.writeAll(lsarray);
		csvwriter.close();
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		DDT_Csv ddtcsv = new DDT_Csv(driver);
		ddtcsv.openUrl("http://newtours.demoaut.com/");
		ddtcsv.readCSV("C:\\Users\\Shravya_Anchuru\\Desktop\\testing", "DDTexcel.csv");
	}
}
