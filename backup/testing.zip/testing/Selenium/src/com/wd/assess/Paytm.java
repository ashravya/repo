package com.wd.assess;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Paytm {

	WebDriver driver;

	public Paytm(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void openApplication(String appUrl) {
		driver.get(appUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void open()
	{
		//driver.findElement(By.xpath(".//*[@id='app']/div/div[2]/div[2]/div[2]/span"));
		if(driver.getTitle().contains("Online recharge")==true)
		{
			System.out.println("Loginpage displayed");
			login();
		}
		
	}
	public void login()
	{
		WebElement login=driver.findElement(By.xpath(".//*[@id='app']/div/div[2]/div[2]/div[4]/div[3]/div"));
		login.click();
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='/v1/api/login?isIframe=true&theme=mp-web']")));
		driver.findElement(By.cssSelector("#input_0")).sendKeys("1234567890");
		
		String num=driver.findElement(By.cssSelector(".number-prefix-new")).getText();
		System.out.println(num);
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath(".//*[@id='app']/div/div[6]/div[2]/div/div/a")).click();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		Paytm pay=new Paytm(driver);
		pay.openApplication("https://paytm.com/");
		pay.open();
		
	}

}
