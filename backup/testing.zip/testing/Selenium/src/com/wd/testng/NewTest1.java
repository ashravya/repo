package com.wd.testng;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class NewTest1 {
	//@Test(priority=0)
	//@Test(dependsOnMethods={"h","g"})
	@Test(groups="smoke",enabled=false)
	public void f() {
		System.out.println("f method!!!!");
		//Assert.assertEquals("EPAM", "epam");
		if("EPAM".equals("epam"))
		{
			Reporter.log("matched");
		}
		else
		{
			Reporter.log("not matched");
		}
	}

	//@Test
	//@Test
	@Test(groups="functional")
	public void g() {
		System.out.println("g method!!!!");
	}

	//@Test(priority=3)
	//@Test(dependsOnMethods="g")
	@Test(groups={"functional","regression"})
	public void h() {
		System.out.println("h method!!!!");
	}
}
