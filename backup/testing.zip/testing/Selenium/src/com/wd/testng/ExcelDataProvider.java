package com.wd.testng;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelDataProvider {

	WebDriver driver;

	@Test(dataProvider = "excelData")
	public void setData(String username, String password) {
		driver.get("http://newtours.demoaut.com/");
		driver.findElement(By.name("userName")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		if (driver.getTitle().contains("Find a Flight")) {
			driver.findElement(By.linkText("SIGN-OFF")).click();
			System.out.println("Correct: " + username + "--" + password);
		} else {
			System.out.println("Wrong: " + username + "--" + password);
		}

	}

	@DataProvider
	public Object[][] excelData() throws IOException {

		File file = new File("C:\\Users\\Shravya_Anchuru\\Desktop\\testing\\DDTexcel.xlsx");
		FileInputStream ifile = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(ifile);
		XSSFSheet sheet = wb.getSheet("MTLoginData");
		Object[][] data = new Object[sheet.getLastRowNum()][2];
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			data[i-1][0] = sheet.getRow(i).getCell(0).getStringCellValue();
			data[i-1][1] = sheet.getRow(i).getCell(1).getStringCellValue();
		}
		ifile.close();
		FileOutputStream ofile = new FileOutputStream(file);
		wb.write(ofile);
		ofile.close();
		return data;
	}

	@BeforeTest
	public void beforeTest() {
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
	}

	@AfterTest
	public void afterTest() {
		if (driver != null) {
			driver.quit();
		}
	}
}
