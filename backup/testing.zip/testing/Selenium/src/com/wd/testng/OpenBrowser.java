package com.wd.testng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class OpenBrowser {
	WebDriver driver;

	@Test
	public void open() {
		driver.get("http://www.google.co.in");
	}
	@Test
	public void search()
	{
		WebElement gSearchBox = driver.findElement(By.name("q"));
		gSearchBox.sendKeys("TestNG");
		gSearchBox.submit();
		//driver.findElement(By.name("btnG")).click();
	}
	@Parameters("browserType")
	@BeforeTest
	public void beforeTest(String browser) {
		driver = Drivers.getDriver(browser);
		driver.manage().window().maximize();	
	}

	@AfterTest
	public void afterTest() {
		//driver.close();
	}
}
/*
<!-- 
<test name="Test1">
 <parameter name="browserType" value="edge"/>
   <classes>
     <class name="com.wd.testng.OpenBrowser"/>
     
   </classes>
 </test> <!-- Test -->
 <test name="Test2">
 <parameter name="browserType" value="firefox"/>
   <classes>
     <class name="com.wd.testng.OpenBrowser"/>
     
   </classes>
 </test> <!-- Test --> 
 -->*/
