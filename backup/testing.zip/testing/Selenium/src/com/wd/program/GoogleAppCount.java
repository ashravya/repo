package com.wd.program;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleAppCount {

	WebDriver driver;

	public GoogleAppCount(WebDriver driver) {

		this.driver = driver;
	}

	

	public void googleAppsCount() {
		WebElement gButton = driver.findElement(By.className("gb_b gb_Vb"));
		gButton.click();
		WebElement elem1 = driver.findElement(By.className("gb_ja gb_ca"));
		List<WebElement> applist1 = elem1.findElements(By.tagName("li"));
		System.out.println("The no of apps are:" + applist1.size());
		for (int i = 0; i < applist1.size(); i++) {
			String appname = applist1.get(i).getText();
			System.out.println(i + 1 + "." + appname);

		}
		
		WebElement elem2 = driver.findElement(By.className("gb_ja gb_da"));
		List<WebElement> applist2 = elem2.findElements(By.tagName("li"));

		System.out.println("The no of apps are:" + applist2.size());
		for (int j = 0; j < applist2.size(); j++) {
			String appname2 = applist2.get(j).getText();
			System.out.println(j + 1 + "." + appname2);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.edge.driver", "D:\\Selenium software\\MicrosoftWebDriver.exe");
		WebDriver driver = new EdgeDriver();
		GoogleAppCount gac = new GoogleAppCount(driver);
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://www.google.co.in");
		gac.googleAppsCount();
		
	}

}

/*
 * <a class="gb_b gb_Vb" href="https://www.google.co.in/intl/en/options/" title=
 * "Google apps" aria-expanded="true" role="button" tabindex="0"
 * data-ved="0EL0nCBQ"></a>
 */