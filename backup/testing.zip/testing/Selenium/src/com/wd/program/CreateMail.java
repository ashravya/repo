package com.wd.program;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CreateMail {
	WebDriver driver;

	public CreateMail(WebDriver driver, String appURL)
	{
		this.driver = driver;
		this.driver.get(appURL);
		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	private void create() {
		// TODO Auto-generated method stub
		driver.findElement(By.cssSelector("#gb_70")).click();
		driver.findElement(By.cssSelector("#link-signup>a")).click(); //create account
		
		driver.findElement(By.cssSelector("#FirstName")).sendKeys("shravya");
		driver.findElement(By.cssSelector("#LastName")).sendKeys("anchuru");
		driver.findElement(By.cssSelector("#GmailAddress")).sendKeys("shravya1234$");
		driver.findElement(By.cssSelector("#LastName")).sendKeys("anchuru");
		
		driver.findElement(By.cssSelector("#Passwd")).sendKeys("123456789");
		driver.findElement(By.cssSelector("#PasswdAgain")).sendKeys("123456789");
		
		driver.findElement(By.cssSelector("div:contains('June')")).click();
		driver.findElement(By.cssSelector("#BirthDay")).sendKeys("13");
		driver.findElement(By.cssSelector("#BirthYear")).sendKeys("1995");
		
		driver.findElement(By.cssSelector("#RecoveryPhoneNumber")).sendKeys("9988776655");
		driver.findElement(By.cssSelector("#RecoveryEmailAddress")).sendKeys("12345@gmail.com");
		//listbox HiddenBirthMonth
		driver.findElement(By.id(":5")).click();
	    driver.findElement(By.xpath("//div[@id=':f']/div")).click();
	    driver.findElement(By.xpath("//div[@id=':k']/div")).click();
		
		
	}

	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		CreateMail mail=new CreateMail(driver, "http://google.co.in");
		mail.create();
	}
	
}

