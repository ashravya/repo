package com.wd.program;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FirstProgram {

	WebDriver driver;

	public FirstProgram(WebDriver driver) {
		this.driver = driver;

	}

	public void openApplication(String appUrl) {
		driver.get(appUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void gSearch(String keyword) {
		WebElement gSearchBox = driver.findElement(By.id("lst-ib"));
		gSearchBox.sendKeys(keyword);
		driver.findElement(By.name("btnG")).click();

		WebDriverWait wait = new WebDriverWait(driver, 10);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("resultStats")));

		String results = driver.findElement(By.id("resultStats")).getText();
		System.out.println(results);

	}

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// System.setProperty("webdriver.edge.driver", "D:\\Selenium
		// software\\MicrosoftWebDriver.exe");
		// WebDriver driver=new EdgeDriver();
		// WebDriver driver = new FirefoxDriver();//open the browser
		FirstProgram wd = new FirstProgram(driver);

		// driver.get("http://www.google.co.in");//http is mandatory
		// driver.manage().window().maximize();

		// driver.manage().timeouts().implicitlyWait(30,
		// TimeUnit.SECONDS);//Standard time out is 30 sec

		// WebElement gSearchBox = driver.findElement(By.id("lst-ib"));
		// gSearchBox.sendKeys("WebDriver");
		// driver.findElement(By.name("btnG")).click();
		// Thread.sleep(5000);
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// WebDriverWait wait = new WebDriverWait(driver, 10);// 10 is converted
		// to
		// seconds
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("resultStats")));

		// String results = driver.findElement(By.id("resultStats")).getText();
		// System.out.println(results);

		wd.openApplication("http://www.google.co.in");
		wd.gSearch("WebDriver");
		driver.quit();
	}
}
