package com.wd.program;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class JQuery {

	WebDriver driver;

	public JQuery(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void dragAndDrop() {
		//Droppable
		driver.findElement(By.xpath(".//*[@id='sidebar']/aside[1]/ul/li[2]/a")).click();
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector(".demo-frame")));
		WebElement Sourcelocator = driver.findElement(By.cssSelector(".ui-draggable"));
		WebElement Destinationlocator = driver.findElement(By.cssSelector(".ui-droppable"));
		(new Actions(driver)).dragAndDrop(Sourcelocator, Destinationlocator).perform();
		/*String actualText = driver.findElement(By.cssSelector("#droppable>p")).getText();
		Assert.assertEquals(actualText, "Dropped!");*/
		drag();		
	}
	public void drag()
	{
		
		driver.get("http://jqueryui.com/draggable");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Rectangle rect=driver.findElement(By.id("draggable")).getRect();
		System.out.println(rect.getX()+" "+rect.getY());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://jqueryui.com/");
		JQuery jq = new JQuery(driver);
		jq.dragAndDrop();

	}

}
