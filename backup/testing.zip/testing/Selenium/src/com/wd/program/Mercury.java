package com.wd.program;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Mercury {

	WebDriver driver;

	public Mercury(WebDriver driver) {

		this.driver = driver;
	}

	public void login() {

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.cssSelector("input[name='userName']")).sendKeys("mercury");
		driver.findElement(By.cssSelector("input[name='password']")).sendKeys("mercury");

		driver.findElement(By.cssSelector("input[name='login']")).click();

	}

	public void verify() {
		List oRadioButton = driver.findElements(By.cssSelector("input[type='radio'][name='tripType']"));
		boolean bValue = false;
		bValue = ((WebElement) oRadioButton.get(0)).isSelected();

		if (bValue == true) {
			System.out.println("Round Trip is selected");
			((WebElement) oRadioButton.get(1)).click();

		}
	}

	public void passenger() {

		/*Select dropdown = new Select(driver.findElement(By.cssSelector("select[name='passCount']")));
		dropdown.selectByValue("2");*/
		driver.findElement(By.cssSelector("select[name='passCount']>option[value='3']")).click();
	}

	public void parisSelection() {

		WebElement select = driver.findElement(By.cssSelector("select[name='fromPort']"));
		Select mySelect = new Select(select);
		List<WebElement> options = mySelect.getOptions();
		for (WebElement option : options) {
			if ("Paris".equals(option.getText()))
				option.click();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://newtours.demoaut.com/");

		Mercury me = new Mercury(driver);
		me.login();

		me.verify();

		me.passenger();

		me.parisSelection();

	}

}
