package com.wd.program;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleHomeLinks {

	WebDriver driver;

	public GoogleHomeLinks(WebDriver driver) {
		this.driver = driver;
	}

	public void googleLinks() {

		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		for(int i=0;i<links.size();i++)
		{
			String linkName=links.get(i).getText();
			System.out.println(i+1+".."+linkName);
		}
		
	}

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		GoogleHomeLinks glinks = new GoogleHomeLinks(driver);
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://www.google.co.in");
		glinks.googleLinks();

	}

}
