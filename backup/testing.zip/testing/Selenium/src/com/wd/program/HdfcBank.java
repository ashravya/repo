package com.wd.program;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.host.Set;

public class HdfcBank {
    WebDriver driver;
    
    public HdfcBank(WebDriver driver) {
		super();
		this.driver = driver;
	}


    public void openApplication(String appUrl){
		driver.get(appUrl);
		driver.manage().window().maximize();
		
	}
    public void validation()
    {
    	if(driver.findElement(By.xpath("//div[@class='selectedvalue']")).getText().equals("NetBanking"))
    	{
    		System.out.println("Present");
    	}
    	String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
    	String subWindowHandler = null;

    	java.util.Set<String> handles = driver.getWindowHandles(); // get all window handles
    	Iterator<String> iterator = handles.iterator();
    	while (iterator.hasNext()){
    	    subWindowHandler = iterator.next();
    	}
    	driver.switchTo().window(subWindowHandler); // switch to popup window
    	  driver.findElement(By.cssSelector("#cee_closeBtn")).click(); // perform operations on popup

    	driver.switchTo().window(parentWindowHandler);  // switch back to parent window
    	driver.findElement(By.xpath("//a[@id='loginsubmit']")).click();
    	    	
    	String parentWindowHandler1 = driver.getWindowHandle(); // Store your parent window
    	String subWindowHandler1 = null;

    	java.util.Set<String> handles1 = driver.getWindowHandles(); // get all window handles
    	Iterator<String> iterator1 = handles1.iterator();
    	while (iterator1.hasNext()){
    	    subWindowHandler1 = iterator1.next();
    	}
    	System.out.println("hello");
    	driver.switchTo().window(subWindowHandler1); // switch to popup window
    	driver.findElement(By.cssSelector(".button > a:nth-child(1) > img:nth-child(1)")).click();  
    	driver.switchTo().frame(driver.findElement(By.xpath("//frame[@name='login_page']")));// perform operations on popup
        driver.findElement(By.cssSelector(".lForm > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(2) > a:nth-child(1) > img:nth-child(1)")).click();
    	  // switch back to parent window
        Alert alert=driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();
		driver.findElement(By.xpath("//table[@class='label']/descendant ::input")).sendKeys("customerid");
		driver.close();
		driver.switchTo().window(parentWindowHandler);
		credit();
		
    }
    public void credit()
    {
    	driver.findElement(By.xpath("//div[@class='loginwrap']/descendant :: div[@class='selectedvalue']")).click();
    	//driver.findElement(By.xpath("//div[@class='expand']/ul/li[@id='creditcardlogin']")).click();
    	WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='expand']/ul/li[@id='creditcardlogin']")));   /*examining the xpath for a search     
        box*/
       // driver.findElement(By.xpath("//*[@id='campaignListTable']")).sendKeys("TEXT");  
        /*enter text in search 
        box*/
        driver.findElement(By.xpath("//a[@id='loginsubmit']")).click();
        driver.findElement(By.xpath("//div[@class='expand']/ul/li[@id='creditcardlogin']")).click();
		driver.findElement(By.xpath("//a[@id='loginsubmit']")).click();
    }


	public static void main(String[] args) {
		
            WebDriver driver=new FirefoxDriver();
            HdfcBank hd = new HdfcBank(driver);
            hd.openApplication("http://www.hdfcbank.com/personal/home");
            hd.validation();
            
	}

}
