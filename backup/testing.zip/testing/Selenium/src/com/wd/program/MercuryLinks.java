package com.wd.program;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MercuryLinks {

	WebDriver driver;
	
	public MercuryLinks(WebDriver driver) {
		
		this.driver = driver;
	}

	public void links() throws InterruptedException
	{
		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		List<String> link =new ArrayList<String>();
		for(WebElement w:links)
        {
			link.add(w.getAttribute("href"));
			
        }
		for(String each:link)
		{
			System.out.println(each);
			this.open(each);
		}
		
					
	}
	public void open(String url) throws InterruptedException{
		this.driver.get(url);
		Thread.sleep(1000);
	}
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		MercuryLinks ml=new MercuryLinks(driver);
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://newtours.demoaut.com/");
		ml.links();
	}

}
