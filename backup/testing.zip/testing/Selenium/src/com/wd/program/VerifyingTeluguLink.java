package com.wd.program;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class VerifyingTeluguLink {

	WebDriver driver;

	public VerifyingTeluguLink(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	public void googleLinks() {

		if (driver.findElement(By.linkText("తెలుగు")) != null) {
			   driver.findElement(By.linkText("తెలుగు")).click();
			   try {
			    driver.findElement(By.linkText("తెలుగు"));
			   } catch (Exception e) {
			    System.out.println("The element తెలుగు is not present");
			   }
			   finally 
			   {
			    if (driver.findElement(By.linkText("English")) != null) 
			     driver.findElement(By.linkText("English")).click();
			    System.out.println("Back to english ");
			   }
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\Training_Softwares\\Krishna\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		VerifyingTeluguLink tlink = new VerifyingTeluguLink(driver);
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://www.google.co.in");
		tlink.googleLinks();
	}

}