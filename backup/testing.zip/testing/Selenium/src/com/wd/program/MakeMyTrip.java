package com.wd.program;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class MakeMyTrip {

	WebDriver driver;
	
	public MakeMyTrip(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public void logic()
	{
		WebElement owt = driver.findElement(By.xpath(".//*[@id='one_way_button1']/span"));
		Actions act = new Actions(driver);
		act.moveToElement(owt);
		act.click().perform();
		
		WebElement from = driver.findElement(By.xpath(".//*[@id='from_typeahead1']"));
		act.moveToElement(from);
		act.click(). sendKeys("Hyd" + Keys.ARROW_DOWN + Keys.TAB).perform();
		
		WebElement to = driver.findElement(By.xpath(".//*[@id='to_typeahead1']"));
		act.moveToElement(to);
		act.click(). sendKeys("Sin" + Keys.ARROW_DOWN + Keys.ENTER).perform();
		
		WebElement widget = driver.findElement(By.cssSelector(".modify_widget"));
		String keys = "";
		act.contextClick(widget).sendKeys(Keys.ARROW_UP).sendKeys(Keys.ENTER).perform();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("https://www.makemytrip.com/flights");
		MakeMyTrip mmt=new MakeMyTrip(driver);
		mmt.logic();
		
	}

}
