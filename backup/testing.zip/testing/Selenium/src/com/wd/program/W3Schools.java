package com.wd.program;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class W3Schools {

	WebDriver driver;

	public W3Schools(WebDriver driver) {

		this.driver = driver;
	}

	public void search() {
		driver.findElement(By.xpath("//i[@class='fa']")).click();
	}

	public void type() {
		driver.findElement(By.xpath("//input[@id='gsc-i-id1']")).sendKeys("Html tables");
		// input class="gsc-search-button gsc-search-button-v2"
		driver.findElement(By.xpath("//input[@class='gsc-search-button gsc-search-button-v2']")).click();
	}

	public void table() {
		// HTML Tables
		driver.findElement(By.xpath("//a[@class='gs-title']")).click();
		driver.findElement(By.xpath("//div[@class='gsc-thumbnail-inside']/div[@class='gs-title']/a[@class='gs-title']/b[text()='HTML Tables']/ancestor::a")).click();
		for(String winHandle : driver.getWindowHandles()){
		   driver.switchTo().window(winHandle);
		}
		String hb=driver.findElement(By.xpath("//table[@id='customers']/tbody/tr[5]/td[2]")).getText();
		if(hb.equals("Helen Bennett"))
		System.out.println("string is present");
		else
		System.out.println("string is not present");
		 
		driver.close();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		FirstProgram first = new FirstProgram(driver);
		first.openApplication("http://www.w3schools.com/");
		W3Schools ws = new W3Schools(driver);
		ws.search();
		ws.type();
		ws.table();
	}

}
