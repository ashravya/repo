package com.wd.practice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class CarLoans {
	WebDriver driver;

	public CarLoans(WebDriver driver) {
		this.driver = driver;
	}

	public void openApplication(String appUrl) {

		driver.get(appUrl);
		driver.manage().window().maximize();
	}

	public void car() {
		driver.findElement(By.xpath(".//*[@id='cee_closeBtn']/img")).click();
		Actions act = new Actions(driver);
		WebElement web = driver.findElement(By.xpath("html/body/div[1]/div[1]/div[2]/div[2]/ul/li[2]/div[1]/a"));
		act.moveToElement(web).perform();
		WebElement web1 = driver.findElement(By.xpath("//a[@class='mainlink'][text()='Loans']"));
		System.out.println(web1.getLocation());
		act.moveToElement(web1);
		act.perform();
		WebElement web2 = driver.findElement(By.xpath("//a[text()='Car Loans']"));
		System.out.println(web2.getLocation());
		//act.moveByOffset(234, 3).sendKeys(Keys.ENTER);
		act.moveByOffset(234, 3);//.click().build().perform();
		/*act.ClickAndHold();
        Actions.Release();
        Actions.Perform();*/
		act.build();
		// act.doubleClick().perform();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		CarLoans m = new CarLoans(driver);
		m.openApplication("http://www.hdfcbank.com/personal/home");
		m.car();
	}

}
