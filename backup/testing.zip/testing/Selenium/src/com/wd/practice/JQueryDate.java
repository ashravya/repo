package com.wd.practice;

import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class JQueryDate {
    private WebDriver driver;

    public JQueryDate(WebDriver driver) {

        this.driver = driver;
    }

    public void open(String url) {
        driver.get(url);
        driver.manage().window().maximize();
    }

    public void past() {
        driver.findElement(By.xpath(".//*[@id='sidebar']/aside[2]/ul/li[6]/a")).click();
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe")));
        driver.findElement(By.xpath((".//*[@id='datepicker']"))).click();
        /*int prmonth = Calendar.getInstance().get(Calendar.MONTH);
        int pryear = Calendar.getInstance().get(Calendar.YEAR);
        int pamonth = 1;
        int payear = 2015;
        int k = (12) * (pryear - payear) + (prmonth - pamonth + 1);*/
        for (int i = 0; i < 20; i++) {

            driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
        }

        driver.findElement(By.linkText("3")).click();
    }

    /*
     * public void future(){ driver.navigate().refresh();
     * driver.findElement(By.xpath(".//*[@id='sidebar']/aside[2]/ul/li[6]/a")).
     * click();
     * driver.switchTo().frame(driver.findElement(By.xpath("//iframe")));
     * driver.findElement(By.xpath((".//*[@id='datepicker']"))).click(); int
     * prmonth=Calendar.getInstance().get(Calendar.MONTH); int
     * pryear=Calendar.getInstance().get(Calendar.YEAR); int frmonth=12;int
     * fryear=2030; int k=(12)*(fryear-pryear)+(frmonth-prmonth+1); for(int
     * i=0;i<k;i++){
     * 
     * driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span"
     * )).click(); }
     * 
     * driver.findElement(By.linkText("3")).click(); }
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        WebDriver driver = new FirefoxDriver();
        JQueryDate date = new JQueryDate(driver);
        date.open("http://jqueryui.com/");
        date.past();
        // date.future();
    }

}
