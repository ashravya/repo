package com.wd.practice;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ScrollDown {
    private WebDriver driver;

    public ScrollDown(WebDriver driver) {

        this.driver = driver;
    }
    public void scroll() throws AWTException{
        Robot robo=new Robot();
        WebElement web=driver.findElement(By.id("darla-assets-bottom"));
        while(web.getSize()!=null){
            robo.keyPress(KeyEvent.VK_PAGE_DOWN);
            //robo.keyRelease(KeyEvent.VK_PAGE_DOWN);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) throws AWTException {
        // TODO Auto-generated method stub
        WebDriver driver = new FirefoxDriver();
        ScrollDown sd=new ScrollDown(driver);
        driver.get("https://in.yahoo.com/?p=us");
        sd.scroll();
    }

}

