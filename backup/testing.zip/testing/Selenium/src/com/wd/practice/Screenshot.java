package com.wd.practice;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Screenshot {
    WebDriver driver;

    public Screenshot(WebDriver driver) {
        this.driver = driver;
    }

    public void openApplication(String appUrl) {

        driver.get(appUrl);
        driver.manage().window().maximize();        
    }
    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
        WebDriver driver = new FirefoxDriver();
        Screenshot m = new Screenshot(driver);
        m.openApplication("http://www.hdfcbank.com/personal/home");
         File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
         FileUtils.copyFile(scrFile, new File("D://screenshot.png"));
    }

}