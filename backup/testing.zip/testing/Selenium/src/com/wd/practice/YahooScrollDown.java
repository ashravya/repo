package com.wd.practice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class YahooScrollDown {
	WebDriver driver;

	public YahooScrollDown(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void openApplication(String appUrl) {
		driver.get(appUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		int i=(int) ((JavascriptExecutor) driver).executeScript("return window.innerHeight;");

		while (true)
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		YahooScrollDown yahoo = new YahooScrollDown(driver);
		yahoo.openApplication("https://in.yahoo.com/?p=us");

	}

}
