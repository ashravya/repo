package ObjectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MT_ObjectRepository {
	public @FindBy(name="userName") WebElement UserName;
	public @FindBy(name="password") WebElement Password;
	public @FindBy(xpath="//*[@value='Login']") WebElement LoginButton;
}
